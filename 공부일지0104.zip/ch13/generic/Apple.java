package ch13.generic;

public class Apple {

}
