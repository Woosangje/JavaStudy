package ch13.generic.multi;

public class Tv {

}
