package ch08.WebBoard;
;

public class ItemBoard extends Board {
	//변수 상품이름추가할것
	String productName;
	


	

	public ItemBoard(String id, String password, String title, String contents, int views, int recommendations, String productName) {
		super(id, password, title, contents, views, recommendations);
		this.productName = productName;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}
	public void printItemBoardInfo(int number) {
		//게시판 정보  번호\t제품명 \t\t제목 \t 조회수 \t 생성일
		System.out.printf("%d \t%s \t%s\t%d\t%s \n",number+1, productName, title, views, printDateTime());
	}

	@Override
	public String toString() {
		return "ItemBoard [productName=" + productName + ", title=" + title + ", contents=" + contents + ", views="
				+ views + ", recommendations=" + recommendations + ", id=" + id + ", password=" + password + "]";
	}
	public void printBoardDetail() {
		System.out.println("# 상품 게시판");
		System.out.println(id + " " +printDateTime() + " ["+ productName +"] " + title);
		System.out.printf("조회수:%d | 추천:%d \n\n", views, recommendations);
		System.out.println("--------------------------------------------");
		System.out.println(contents);
		System.out.println("--------------------------------------------");
		
	}
	

	
	
	
	
	
	
}
