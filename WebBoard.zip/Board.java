package ch08.WebBoard;

import java.time.LocalDateTime;

public class Board extends Member{

	String title;
	String contents;//내용
	int views;//조회수
	int recommendations;//추천
	LocalDateTime now;//날짜
	int year;
	int monthValue;
	int dayOfMonth;//요일

	public Board(String id, String password, String title, String contents, int views, int recommendations) {
		super(id, password);
		this.title = title;
		this.contents = contents;
		this.views = views;
		this.recommendations = recommendations;
		this.now = LocalDateTime.now();
		this.year = now.getYear();
		this.monthValue = now.getMonthValue();
		this.dayOfMonth =now.getDayOfMonth();
	}
	
	String printDateTime() {
		return year + "-" + monthValue + "-" + dayOfMonth;
	}
	
	
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContents() {
		return contents;
	}
	public void setContents(String contents) {
		this.contents = contents;
	}
	public int getViews() {
		return views;
	}
	public void setViews(int views) {
		this.views = views;
	}
	public int getRecommendations() {
		return recommendations;
	}
	public void setRecommendations(int recommendations) {
		this.recommendations = recommendations;
	}
	public LocalDateTime getNow() {
		return now;
	}
	public void setNow(LocalDateTime now) {
		this.now = now;
	}
	
	
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public int getMonthValue() {
		return monthValue;
	}
	public void setMonthValue(int monthValue) {
		this.monthValue = monthValue;
	}
	public int getDayOfMonth() {
		return dayOfMonth;
	}
	public void setDayOfMonth(int dayOfMonth) {
		this.dayOfMonth = dayOfMonth;
	}




	
}
