package ch08.WebBoard;

public class FreeBoard extends Board {

	String free ="자유";

	// 게시판 닉네임, 제목
	// 글쓰기
	//
	public FreeBoard(String id, String password, String title, String contents, int views, int recommendations,
			String free) {
		super(id, password, title, contents, views, recommendations);
		this.free = free;
	}

	public void printFreeBoardInfo(int number) {
		// 게시판 정보 번호\t\t제목 \t 조회수 \t 생성일
		System.out.printf("%d \t%s\t%d\t%s \n", number + 1, title, views, printDateTime());
	}

	// 기본 생성자(자동)
	public void printBoardDetail() {
		System.out.println("# 상품 게시판");
		System.out.println(id + " " + printDateTime() + " [" + free + "] " + title);
		System.out.printf("조회수:%d | 추천:%d \n\n", views, recommendations);
		System.out.println("--------------------------------------------");
		System.out.println(contents);
		System.out.println("--------------------------------------------");

	}

}
