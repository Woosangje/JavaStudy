package ch08.WebBoard;

import java.util.Scanner;

public class WebBoardExam {

	private static Scanner in = new Scanner(System.in);
	private static Member[] memberArr = new Member[100];// 계정생성
	private static Member loggedInMember = null;

	// 게시판
	private static ItemBoard[] itemBoardArr = new ItemBoard[100];
	private static FreeBoard[] freeBoardArr = new FreeBoard[100];
	
	public static void main(String[] args) {
		//
		boolean isRun = true;
		while (isRun) {
			System.out.println("1. 로그인  2. 회원가입  3. 게시판  4. 종료");
			System.out.println("5. 관리자");
			int select = in.nextInt();
			switch (select) {
			case 1:
				login();
				break;
			case 2:
				createAccount();
				break;
			case 3:
				// 로그인 해야 입장가능

				noticeBoard();

				break;
			case 4:
				System.out.println("종료");
				isRun = false;
				break;
			case 5:
				break;
			default:
				System.out.println("입력오류");
				break;
			}
		}
	}

	private static void login() {
		// case 로그인
		System.out.println("-----     로그인     -----");
		System.out.println("아이디: ");
		String id = in.next();
		System.out.println("패스워드: ");
		String password = in.next();
		loggedInMember = findMember(id, password);
		if (loggedInMember != null) {
			// 로그인되었을경우
			System.out.println("로그인이 되었습니다.");
			loggedInMember.printUserInfo();

			if (loggedInMember == null) {
				System.out.println("로그인 오류 발생");
			}

		} else {
			System.out.println("아이디나 패스워드가 다릅니다.");
		}
	}

	private static void createAccount() {
		// 회원가입
		System.out.println("-----     계정생성     -----");
		System.out.println("아이디: ");

		String id = findId(in.next());
		System.out.println("패스워드: ");
		String password = in.next();

		Member newMember = new Member(id, password);

		for (int i = 0; i < memberArr.length; i++) {// 아이디생성
			if (memberArr[i] == null) {
				memberArr[i] = newMember;
				System.out.println("--      생성완료      --");
				memberArr[i].printUserInfo();
				break;
			}
		}

	}

	private static String findId(String id) {

		for (int i = 0; i < memberArr.length; i++) {
			if (memberArr[i] != null) { // 빈칸이 아니면
				String dbId = memberArr[i].getId();

				if (dbId.equals(id)) {
					// 같은 id가 이미 존재하는지
					System.out.println("이미 존재하는 아이디 입니다.");
					return null;
				}

			}
		} // 배열 반복용 코드
		return id;

	}

	private static Member findMember(String id, String password) {
		// memberArr 에서 반환
		Member member = null;
		for (int i = 0; i < memberArr.length; i++) {
			if (memberArr[i] != null) {
				String dbId = memberArr[i].getId();
				String dbPw = memberArr[i].getPassword();
				if (dbId.equals(id) && dbPw.equals(password)) {
					member = memberArr[i];
					break;
				} else {

				}
			}

		}

		return member;
	}

	private static void noticeBoard() {
		// case3 게시판
		boolean isRun = true;
		while (isRun) {
			if (loggedInMember != null) {
				System.out.println("--              게시판              --");
				System.out.println("1. 상품 게시판   2. 자유게시판   3. 뒤로가기 ");
				System.out.println("4. 게시판 자동 생성");
				int select3 = in.nextInt();
				switch (select3) {
				case 1:
					System.out.println("---            상품게시판            ---");
					System.out.println("번호\t제품명 \t제목 \t\t 조회수 \t생성일");
					boolean isBoard = false;
					for (int i = 0; i < itemBoardArr.length; i++) {
						// 게시판 목록 출력
						if (itemBoardArr[i] != null) {

							itemBoardArr[i].printItemBoardInfo(i);// 출력
							isBoard = true;
						}
					}
					if (isBoard == false) {// 게시판이없을경우 공백을생성하고 번호를 입력하지 않는다.
						System.out.println();
						System.out.println("---     --------------------     ---");
						System.out.println("게시판 정보가 없습니다.");
					} else {
						System.out.println("---     --------------------     ---");
						System.out.println("게시판 번호입력: ");
						int input = in.nextInt();

						for (int i = 0; i < itemBoardArr.length; i++) {
							if (itemBoardArr[i] != null && i == input-1) {
								// 게시판 상세 내용
								itemBoardArr[i].printBoardDetail();
								break;
							}

						}
					}//else end
					System.out.println();
					break;
				case 2:
					//자유게시판
					System.out.println("---            자유게시판            ---");
					System.out.println("번호 \t제목 \t\t 조회수 \t생성일");
					boolean isBoard2 = false;
					for (int i = 0; i < freeBoardArr.length; i++) {
						// 게시판 목록 출력
						if (freeBoardArr[i] != null) {

							freeBoardArr[i].printFreeBoardInfo(i);// 출력
							isBoard2 = true;
						}
					}
					if (isBoard2 == false) {// 게시판이없을경우 공백을생성하고 번호를 입력하지 않는다.
						System.out.println();
						System.out.println("---     --------------------     ---");
						System.out.println("게시판 정보가 없습니다.");
					} else {
						System.out.println("---     --------------------     ---");
						System.out.println("게시판 번호입력: ");
						int input = in.nextInt();

						for (int i = 0; i < freeBoardArr.length; i++) {
							if (freeBoardArr[i] != null && i == input-1) {
								// 게시판 상세 내용
								freeBoardArr[i].printBoardDetail();
								break;
							}

						}
					}//else end
					break;
				case 3:
					isRun = false;
					break;
				case 4:
					// 상품게시판임의로 추가
					int count = 0;
					for (int i = 0; i < itemBoardArr.length; i++) {

						if (itemBoardArr[i] == null && freeBoardArr[i] == null && count < 5) {// 임으로5개만들거임
							//상품게시판 생성
							itemBoardArr[i] = createRandomItemBoard();
							System.out.println(itemBoardArr[i].toString());
							//자유게시판 생성
							freeBoardArr[i] = createRandomFreeBoard();
							System.out.println(freeBoardArr[i].toString());
							count++;
						}

					}

					break;
				default:
					break;

				}

			} else {
				System.out.println("로그인시 이용가능합니다.");
				isRun = false;

			}
		} // while (isRun) end
	}

	private static ItemBoard createRandomItemBoard() {
		// case2 랜덤 정보: 아이디 패스워드 입력 타이틀, 내용 조회수, 추천, 제품이름
		String id = "가나다라";
		String password = "1234";
		String title = "기스가 보여요";
		String contents = "기스가 보여요 텍스트 및 전체 문서 파일을 즉시 번역하세요. 개인과 팀을 위한 정확한 AI 번역. 매일 수백만 명이";
		int views = (int) (Math.random() * 500) + 1;
		int recommendations = (int) (Math.random() * 40) + 1;
		String[] instanceName = { "소파", "의자", "책상" };
		String productName = instanceName[(int) (Math.random() * 3)];

		ItemBoard itemBoard = new ItemBoard(id, password, title, contents, views, recommendations, productName);

		return itemBoard;

	}
	private static FreeBoard createRandomFreeBoard() {
		// case2 랜덤 정보: 아이디 패스워드 입력 타이틀, 내용 조회수, 추천, 제품이름
		String id = "자유인123";
		String password = "1234";
		String title = "자전거123";
		String contents = "자전거 타기123  텍스트 및 전체 문서 파일을 즉시 번역하세요. 개인과 팀을 위한 정확한 AI 번역. 매일 수백만 명이";
		int views = (int) (Math.random() * 200) + 1;
		int recommendations = (int) (Math.random() * 20) + 1;
		String free = "자유";
		FreeBoard freeBoard = new FreeBoard(id, password, title, contents, views, recommendations, free);

		return freeBoard;

	}

}
