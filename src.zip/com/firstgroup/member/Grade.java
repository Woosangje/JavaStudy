package com.firstgroup.member;

public enum Grade {
	Diamond,
	Platinum,
	Gold,
	Silver,
	Bronze,
	Iron
}