package com.firstgroup.member;


public class User extends Member{
	final int MEMBER_KEY;
	
	public User(int MEMBER_KEY, String pass, String name) {
		this.MEMBER_KEY = MEMBER_KEY;
		this.pw = pass;
		this.name = name;
		this.nickNamd = name;
		this.admin = false;
	}
	public User(int MEMBER_KEY,String pass, String name, String nickName) {
		this.MEMBER_KEY = MEMBER_KEY;
		this.pw = pass;
		this.name = name;
		this.nickNamd = nickName;
		this.admin = false;
	}
	
	
	public int getMEMBER_KEY() {
		return MEMBER_KEY;
	}
	@Override
	boolean checkPw(String pw) {
		return this.pw.equals(pw);
	}
}
