package com.firstgroup.member;


public abstract class Member {
	String pw; //<id,pass>
	String name; //이름
	String nickNamd; // 닉네임 
	String adress; // 주소 
	String phone; // 휴대폰번호 
	Grade grade; // 등급
	boolean admin; // true일 경우 관리
	int contextCount; //게시글 작성 수 
	int commentCount; //댓글 작성 수
	
	

	public String getPw() {
		return pw;
	}

	public String getName() {
		return name;
	}

	public String getNickNamd() {
		return nickNamd;
	}

	public String getAdress() {
		return adress;
	}

	public String getPhone() {
		return phone;
	}

	public Grade getGrade() {
		return grade;
	}

	public boolean isAdmin() {
		return admin;
	}

	public int getContextCount() {
		return contextCount;
	}

	public int getCommentCount() {
		return commentCount;
	}

	public void setPw(String pw) {
		this.pw = pw;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setNickNamd(String nickNamd) {
		this.nickNamd = nickNamd;
	}

	public void setAdress(String adress) {
		this.adress = adress;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public void setGrade(Grade grade) {
		this.grade = grade;
	}

	public void setAdmin(boolean admin) {
		this.admin = admin;
	}

	public void setContextCount(int contextCount) {
		this.contextCount = contextCount;
	}

	public void setCommentCount(int commentCount) {
		this.commentCount = commentCount;
	}

	abstract boolean checkPw(String pw);
	
	boolean checkAdmin() {
		return admin;
	}
	
}
