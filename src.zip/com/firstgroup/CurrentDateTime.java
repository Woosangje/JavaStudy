package com.firstgroup;

import java.time.LocalDateTime;
import java.util.Date;

public class CurrentDateTime {
	//현재 날짜/시간
	static private LocalDateTime now= LocalDateTime.now();
	Date date = new Date();
	// 현재 날짜/시간 출력
	
	int year = now.getYear();
	String month = now.getMonth().toString(); //월(문자열)
	int monthValue = now.getMonthValue(); // 월(숫자)
	int dayOfMonth = now.getDayOfMonth(); // 일(년 기준)
	int dayOfYear = now.getDayOfYear(); //일(년 기준)
	String dayOfWeek = now.getDayOfWeek().toString(); //요일(문자열)
	int dayOfWeekValue = now.getDayOfWeek().getValue(); //요일(숫자)
	int hour = now.getHour();
	int minute = now.getMinute();
	int second = now.getSecond();
	public static LocalDateTime getNow() {
		return now;
	}
	public int getYear() {
		return year;
	}
	public String getMonth() {
		return month;
	}
	public int getMonthValue() {
		return monthValue;
	}
	public int getDayOfMonth() {
		return dayOfMonth;
	}
	public int getDayOfYear() {
		return dayOfYear;
	}
	public String getDayOfWeek() {
		return dayOfWeek;
	}
	public int getDayOfWeekValue() {
		return dayOfWeekValue;
	}
	public int getHour() {
		return hour;
	}
	public int getMinute() {
		return minute;
	}
	public int getSecond() {
		return second;
	}
	public static void setNow(LocalDateTime now) {
		CurrentDateTime.now = now;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public void setMonthValue(int monthValue) {
		this.monthValue = monthValue;
	}
	public void setDayOfMonth(int dayOfMonth) {
		this.dayOfMonth = dayOfMonth;
	}
	public void setDayOfYear(int dayOfYear) {
		this.dayOfYear = dayOfYear;
	}
	public void setDayOfWeek(String dayOfWeek) {
		this.dayOfWeek = dayOfWeek;
	}
	public void setDayOfWeekValue(int dayOfWeekValue) {
		this.dayOfWeekValue = dayOfWeekValue;
	}
	public void setHour(int hour) {
		this.hour = hour;
	}
	public void setMinute(int minute) {
		this.minute = minute;
	}
	public void setSecond(int second) {
		this.second = second;
	}
	
	//년, 월(문자열, 숫자), 일(월 기준, 년 기준), 요일(문자열, 숫자), 시, 분, 초 출력
	
	
	
}
