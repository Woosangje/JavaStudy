package com.firstgroup.board;

import java.util.Date;

public class Item {
	String image;
	Date date;
	int price;
	String address;
}
