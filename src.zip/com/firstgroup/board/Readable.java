package com.firstgroup.board;

public interface Readable {
	public void readContent();
}
