package com.firstgroup.board;

public class Context {
	final int CONTEXT_KEY;
	String title;
	String content;
	String writer;
	int star;
	int viewCount;
	
	public Context(int CONTEXT_KEY) {
		this.CONTEXT_KEY = CONTEXT_KEY;
	}

	public Context(int CONTEXT_KEY, String title, String content, String writer) {
		this.CONTEXT_KEY = CONTEXT_KEY;
		this.title = title;
		this.content = content;
		this.writer = writer;
	}
	
	

	public int getCONTEXT_KEY() {
		return CONTEXT_KEY;
	}

	public String getTitle() {
		return title;
	}

	public String getContent() {
		return content;
	}

	public String getWriter() {
		return writer;
	}

	public int getStar() {
		return star;
	}

	public int getViewCount() {
		return viewCount;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public void setWriter(String writer) {
		this.writer = writer;
	}

	public void setStar(int star) {
		this.star = star;
	}

	public void setViewCount(int viewCount) {
		this.viewCount = viewCount;
	}
	
	
}
