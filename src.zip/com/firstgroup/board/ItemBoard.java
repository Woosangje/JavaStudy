package com.firstgroup.board;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.firstgroup.CurrentDateTime;
import com.firstgroup.member.User;

public class ItemBoard extends Board {
	List<ItemContext> itemContents = new ArrayList<ItemContext>();
	CurrentDateTime currentDateTime = new CurrentDateTime();

	@Override
	public void deleteContent() {
		try {
			Scanner in = new Scanner(System.in);
			System.out.println("삭제할 게시물을 선택해 주세요");
			showContent();
			System.out.print(">>> ");
			int select = in.nextInt() - 1;
			this.itemContents.remove(select);
		} catch (Exception e) {
			System.out.println("잘못입력하셨습니다.");
		}
	}

	public void showContent() {
		System.out.println("---------------------------------------");
		for (int i = 0; i < itemContents.size(); i++) {

			System.out.printf("%d.| %s | 이미지:%s | %s | %s원\n", i + 1, itemContents.get(i).getTitle(),
					itemContents.get(i).getImage(), itemContents.get(i).getAddress(), itemContents.get(i).getPrice());

		}
		System.out.println("---------------------------------------");
	}

	@Override
	public void updateContent() {

		if (itemContents.size() != 0) {
			try {
				Scanner in = new Scanner(System.in);
				showContent();
				System.out.println("수정할 게시물을 선택하세요");
				System.out.print(">>> ");
				int num = in.nextInt() - 1;
				if (itemContents.get(num) != null) {
					// System.out.println("해당 번호의 게시물이 없습니다.");
					System.out.println("수정할 항목을 선택하세요");
					System.out.println("1. 제목 | 2. 내용 | 3. 이미지");
					System.out.print(">>> ");
					int select = in.nextInt();
					in.nextLine();
					switch (select) {
					case 1:
						System.out.println("제목을 입력하세요");
						System.out.print(">>> ");
						String title = in.nextLine();
						itemContents.get(num).setTitle(title);
						break;
					case 2:
						System.out.println("내용을 입력하세요");
						System.out.print(">>> ");
						String text = in.nextLine();
						itemContents.get(num).setContent(text);
						break;
					case 3:
						System.out.println("이미지를 입력하세요");
						System.out.print(">>> ");
						String image = in.nextLine();
						itemContents.get(num).setImage(image);
						break;
					default:
						System.out.println("잘못된 번호입니다.");

					}

				}
			} catch (Exception e) {
				System.out.println("잘못 입력하셨습니다.");
			}

		} else {
			System.out.println("게시물이 존재하지 않습니다.");
		}
	}

	@Override
	public void readContent() {

		if (itemContents.size() != 0) {
			try {
				System.out.println("읽을 게시물 번호를 입력하세요");
				Scanner in = new Scanner(System.in);
				int num = in.nextInt() - 1;
				ItemContext tmp = itemContents.get(num);
				System.out.println("#----------------------------------#");
				System.out.println(tmp.getTitle());

				SimpleDateFormat formatter = new SimpleDateFormat("YYYY년MM월DD일");
				String formatedNow = formatter.format(tmp.getDate());

				System.out.println(formatedNow);// 게시날짜
				System.out.println("#-              내용                -#");

				String sTmp = tmp.getContent();
				System.out.println("|             " + tmp.getImage() + "           |");
				String[] tmp2 = new String[sTmp.length()];
				for (int i = 0; i < tmp2.length; i++) {
					tmp2[i] = sTmp.substring(i, i + 1);
				}
				for (int i = 1; i < tmp2.length + 1; i++) {
					System.out.print(tmp2[i - 1]);
					if (i % 25 == 0)
						System.out.println();
				}
				System.out.println();
				System.out.println("거래희망장소: " + itemContents.get(num).getAddress());
				System.out.println("#----------------------------------#");
			} catch (Exception e) {
				System.out.println("잘못 입력하셨습니다.");
			}
		} else {
			System.out.println("게시물이 존재하지 않습니다.");
		}
	}

	public void creatContent(User user) {
		int count = findCount();
		Scanner in = new Scanner(System.in);
		System.out.println("이미지를 입력하세요");
		System.out.print(">>> ");
		String image = in.next();
		System.out.println("제목을 입력하세요");
		System.out.print(">>> ");
		String title = in.next();
		System.out.println("가격을 입력해주세요.");
		int price = in.nextInt();

		System.out.println("내용을 입력하세요");
		System.out.print(">>> ");
		String text = in.next();
		String writer = "ano";
		// 게시날짜
		Date date = new Date();

		System.out.println("거래 희망 장소");
		System.out.print(">>> ");
		String address = in.next();
		try {
			if (user.getNickNamd() != null)
				writer = user.getNickNamd();
		} catch (Exception e) {
		}
		itemContents.add(new ItemContext(count, title, text, writer, image, date, price, address));
	}

	private int findCount() {
		int result = 0;
		for (int i = 0; i < this.itemContents.size(); i++) {
			if (result <= this.itemContents.get(i).getCONTEXT_KEY())
				result = this.itemContents.get(i).getCONTEXT_KEY();
		}
		result++;
		return result;
	}
}
