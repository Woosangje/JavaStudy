package com.firstgroup.board;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.firstgroup.member.User;

public class Board implements Creatable, Readable, Updateable, Deleteable{
	List<Context> contents = new ArrayList<Context>();


	@Override
	public void deleteContent() {
		Scanner in = new Scanner(System.in);
		System.out.println("삭제할 게시물을 선택해 주세요");
		showContent();
		System.out.print(">>> ");
		int select = in.nextInt()-1;
		this.contents.remove(select);
		}

	public void showContent() {

		System.out.println("---------------------------------------");
		for (int i = 0 ; i < contents.size();i++) {
			System.out.printf("%d. | %s | %s\n",i+1,contents.get(i).getTitle(),contents.get(i).getWriter());
		}

		System.out.println("---------------------------------------");
	}

	@Override
	public void updateContent() {
		Scanner in = new Scanner(System.in);
		showContent();
		System.out.println("수정할 게시물을 선택하세요");
		System.out.print(">>> ");
		int num = in.nextInt()-1;
		System.out.println("수정할 항목을 선택하세요");
		System.out.println("1. 제목 | 2. 내용");
		System.out.print(">>> ");
		int select = in.nextInt();
		in.nextLine();
		switch(select) {
		case 1:
			System.out.println("제목을 입력하세요");
			System.out.print(">>> ");
			String title = in.nextLine();
			contents.get(num).setTitle(title);
			break;
		case 2:
			System.out.println("내용을 입력하세요");
			System.out.print(">>> ");
			String text = in.nextLine();
			contents.get(num).setContent(text);
			break;
		default:
			System.out.println("잘못된 번호입니다.");
			
		}
	}

	@Override
	public void readContent() {
		System.out.println("읽을 게시물 번호를 입력하세요");
		Scanner in = new Scanner(System.in);
		int num = in.nextInt()-1;
		Context tmp = contents.get(num);
		System.out.println("------------------------------------");
		System.out.println(tmp.getTitle());
		System.out.println("------------------------------------");
		String sTmp = tmp.getContent();
		String[] tmp2 = new String[sTmp.length()];
		for (int i = 0 ; i < tmp2.length ; i ++) {
			tmp2[i] = sTmp.substring(i, i+1);
		}
		for (int i = 1 ; i <tmp2.length+1 ; i ++) {
			System.out.print(tmp2[i-1]);
			if (i%25==0) System.out.println();
		}
		System.out.println();
		System.out.println("------------------------------------");
	}

	@Override
	public void creatContent() {
		int count = findCount();
		Scanner in = new Scanner(System.in);
		System.out.println("제목을 입력하세요");
		System.out.print(">>> ");
		String title = in.nextLine();
		System.out.println("내용을 입력하세요");
		System.out.print(">>> ");
		String text = in.nextLine();
		String writer = "ano";
		contents.add(new Context(count, title, text, writer));
	}
	
	public void creatContent(User user) {
		int count = findCount();
		System.out.println("이미지: sample");
		Scanner in = new Scanner(System.in);
		System.out.println("제목을 입력하세요");
		System.out.print(">>> ");
		String title = in.nextLine();
		System.out.println("내용을 입력하세요");
		System.out.print(">>> ");
		String text = in.nextLine();
		String writer = "ano";
		try {if (user.getNickNamd()!= null) writer =user.getNickNamd(); }
		catch(Exception e) {}
		contents.add(new Context(count, title, text, writer));
	}

	private int findCount() {
		int result = 0;
		for (int i = 0 ; i < this.contents.size() ; i ++) {
			if (result <= this.contents.get(i).getCONTEXT_KEY()) result = this.contents.get(i).getCONTEXT_KEY();
		}
		result++;
		return result;
	}
}
