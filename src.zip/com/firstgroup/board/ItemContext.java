package com.firstgroup.board;

import java.util.Date;

public class ItemContext extends Context{
	String image;
	Date date;
	int price;
	String address;
	
	public ItemContext(int CONTEXT_KEY) {
		super(CONTEXT_KEY);
		// TODO Auto-generated constructor stub
	}

	public ItemContext(int CONTEXT_KEY, String title, String content, String writer, String image, Date date, int price,
			String address) {
		super(CONTEXT_KEY, title, content, writer);
		this.image = image;
		this.date = date;
		this.price = price;
		this.address = address;
	}

	public String getImage() {
		return image;
	}

	public Date getDate() {
		return date;
	}

	public int getPrice() {
		return price;
	}

	public String getAddress() {
		return address;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	

}
