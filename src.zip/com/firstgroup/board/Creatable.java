package com.firstgroup.board;

public interface Creatable {
	public void creatContent();
}
