package com.firstgroup.board;

public interface Deleteable {
	public void deleteContent();
}
