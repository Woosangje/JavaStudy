package com.firstgroup.board;

public interface Updateable {
	public void updateContent();
}
