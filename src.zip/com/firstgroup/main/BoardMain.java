package com.firstgroup.main;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

import com.firstgroup.board.Board;
import com.firstgroup.board.ItemBoard;
import com.firstgroup.member.User;

public class BoardMain {
	static HashMap<String,Integer> users = new HashMap<String, Integer>();
	static List<User> userInfos = new ArrayList<User>();
	static Scanner in = new Scanner(System.in);
	static Board b = new Board();
	static String ID = null;
	static User currentUser = null;
	
	static ItemBoard itemboard = new ItemBoard();
	
	public static void main(String[] args) {
		boolean run = true;
		boolean isLogin = false;
		while (run) {
			int selectMenu = showMenus(isLogin);
			switch(selectMenu) {
			case 1:
				if (isLogin) {
					isLogin = false;
					ID = null;
					currentUser = null;
				}
				else isLogin = login();
				continue;
			case 2:
				boolean fb = true;
				while(fb) {
					b.showContent();
					System.out.println("1. 게시불 작성 | 2. 게시물 보기 | 3. 게시물 수정");
					System.out.println("4. 게시불 삭제 | \t\t  | 5. 종료");
					System.out.print(">>> ");
					int selectBoardMenu = in.nextInt();
					switch(selectBoardMenu) {
					case 1:
						b.creatContent(currentUser);
						break;
					case 2:
						b.readContent();
						break;
					case 3:
						b.updateContent();
						break;
					case 4:
						b.deleteContent();
						break;
					case 5:
						fb = false;
						break;
					default :
						System.out.println("잘못된 선택입니다.");
					}
				}
				continue;
			case 3:
				
				continue;
			case 4:
				boolean isRun = true;
				while(isRun) {
					itemboard.showContent();
					System.out.println("1. 게시불 작성 | 2. 게시물 보기 | 3. 게시물 수정");
					System.out.println("4. 게시불 삭제 | \t\t  | 5. 종료");
					System.out.print(">>> ");
					int selectBoardMenu = in.nextInt();
					switch(selectBoardMenu) {
					case 1:
						itemboard.creatContent(currentUser);
						break;
					case 2:
						itemboard.readContent();
						break;
					case 3:
						itemboard.updateContent();
						break;
					case 4:
						itemboard.deleteContent();
						break;
					case 5:
						isRun = false;
						break;
					default :
						System.out.println("잘못된 선택입니다.");
					}
				}
				continue;
			case 5:
				
				continue;
			case 6:
				System.out.println("프로그램을 종료합니다.");
				run = false;
				break;
			default:
				System.out.println("잘못된 메뉴 선택입니다.");
			}
		}
	}
	
	
	
	
	
	
	private static boolean login() {
		// TODO Auto-generated method stub

		System.out.println("---------------------------------------");
		System.out.println("1. 로그인 \t\t2. 회원가입");
		System.out.println("---------------------------------------");
		System.out.print(">>> ");
		int select = in.nextInt();
		boolean result = false;
		switch(select) {
		case 1:
			for (int i = 0 ; i < 5 ; i ++) {
				System.out.println("아이디를 입력하세요");;
				System.out.print(">>> ");
				String id = in.next();
				if(users.containsKey(id)) {
					User user = findUser(users.get(id));
					System.out.println("비밀번호를 입력하세요");;
					System.out.print(">>> ");
					String pw = in.next();
					if (user.getPw().equals(pw)) {
						System.out.printf("환영합니다. %s님\n",user.getNickNamd());
						result = true;
						currentUser = userInfos.get( users.get(id)-1);
						break;
					} else System.out.println("비밀번호가 잘못되었습니다.");
				}else System.out.println("아이디가 잘못되었습니다.");
			}	
			break;
		case 2:
			createUser();
			break;
		default:
			System.out.println("잘못된 입력입니다.");
		}
		return result;
	}



	private static User findUser(Integer integer) {
		User user = null;
		for (int i = 0 ; i < userInfos.size() ; i++) {
			int tmp = userInfos.get(i).getMEMBER_KEY();
			if (tmp == integer) {
				user = userInfos.get(i);
				break;
			}
		}
		return user;
	}



	private static int showMenus(boolean isLogin) {
		System.out.println("---------------------------------------");
		if (isLogin) {
			System.out.println("1. 로그아웃\t\t3. ");
		}else {
			System.out.println("1. 로그인\t\t\t3. ");	
		}
		
		System.out.println("2. 자유게시판\t\t4. 중고 거래 게시판");
		System.out.println("3. 자료 공유\t\t6. 종료 ");
		
		System.out.println("---------------------------------------");
		System.out.print(">>> ");
		return in.nextInt();
	}



	static void createUser() {
		System.out.println("사용하실 ID를 입력해 주세요.");
		System.out.print(">>> ");
		String id = in.next();
		int index = findUserCount();
		index++;
		users.put(id, index);
		boolean isPassSame = false;
		String pass = null;
		while(!isPassSame) {
			System.out.println("사용하실 비밀번호를 입력해 주세요.");
			System.out.print(">>> ");
			pass = in.next();
			System.out.println("비밀번호를 한번 더 입력해 주세요.");
			System.out.print(">>> ");
			String passTmp = in.next();
			isPassSame = pass.equals(passTmp);
			if (!isPassSame) {
				System.out.println("비밀번호가 일치하지 않습니다.");
			}
		}
		System.out.println("사용자의 이름 입력해 주세요.");
		System.out.print(">>> ");
		String name = in.next();
		System.out.println("사용자의 닉네임을 입력해 주세요.");
		System.out.println("닉네임을 사용하지 않으려면 n를 입력해 주세요.");
		System.out.print(">>> ");
		String nickName = in.next();
		if (nickName.toLowerCase().equals("n")) {
			userInfos.add(new User(index, pass, name));
		} else {
			userInfos.add(new User(index, pass, name, nickName));
		}
		System.out.println("회원가입이 완료되었습니다.");
	}

	private static int findUserCount() {
		int index = 0;
		for (int i = 0 ; i < userInfos.size();i++) {
			int tmp = 0;
			if (userInfos.get(i).getMEMBER_KEY() > tmp) {
				tmp = userInfos.get(i).getMEMBER_KEY();
			}
		}
		return index;
	}
}
