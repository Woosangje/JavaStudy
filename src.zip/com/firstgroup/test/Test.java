package com.firstgroup.test;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.firstgroup.board.Board;
import com.firstgroup.fileio.FileManager;
import com.firstgroup.member.User;

public class Test {

	public static void main(String[] args) {
	Date date = new Date();
	System.out.println(date);
	
	}
	
}
