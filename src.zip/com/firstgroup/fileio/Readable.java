package com.firstgroup.fileio;

import java.util.ArrayList;
import java.util.List;

public interface Readable {
	public abstract List<List<String>> readCSV(String fileName);
}
