package com.firstgroup.fileio;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class FileManager implements Readable,Writeable{
	String fileName;
	public FileManager() {
		
	}
	
	public FileManager(String fileName) {
		this.fileName = fileName;
	}
	
	
	@Override
	public void writeCSV(List<List<String>> lists,String fileName) {
		// TODO Auto-generated method stub
		BufferedWriter bufferedWriter = null;
		StringBuilder tmp = new StringBuilder();
		tmp.append(Paths.get("").toAbsolutePath().toString());
		tmp.append(String.format("\\src\\repository\\%s.csv",fileName));
		String path = tmp.toString();
		try {
			bufferedWriter = Files.newBufferedWriter(Paths.get(path), Charset.forName("UTF-8"));
			
//			List<List<String>> allData = readCSV(fileName);
//			for (List<String> newLine : lists) {
//				allData.add(newLine);
//			}
			for (List<String> newLine : lists) {

                // 1행분의 데이터
                List<String> list = newLine;

                for (String data : list) {
                    bufferedWriter.write(data);
                    bufferedWriter.write(",");
                }
                bufferedWriter.newLine();
            }
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if(bufferedWriter!=null) {
				try {
				bufferedWriter.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	@Override
	public List<List<String>> readCSV(String fileName) {
		List<List<String>> csvList = new ArrayList<List<String>>();
		BufferedReader br = null;
		StringBuilder tmp = new StringBuilder();
		tmp.append(Paths.get("").toAbsolutePath().toString());
		tmp.append(String.format("\\src\\repository\\%s.csv",fileName));
		String path = tmp.toString();
		
		File csv = new File(path);
		try {
			br = Files.newBufferedReader(Paths.get(path));
			String line = "";
			while((line = br.readLine())!=null) {
				List<String> tmpList = new ArrayList<String>();
				String array[] = line.split(",");
				tmpList = Arrays.asList(array);
				csvList.add(tmpList);
			}
		} catch(FileNotFoundException | NoSuchFileException e) { 
			createCSV(path);
		}catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if(br!=null) {try {
				br.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}}
		}
		return csvList;
	}

	private void createCSV(String path) {
		try {
			System.out.println(path);
			FileOutputStream file = new FileOutputStream(path, true);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	

}
