package com.firstgroup.fileio;

import java.util.List;

public interface Writeable {
	public abstract void writeCSV(List<List<String>> list, String fileName);
}
