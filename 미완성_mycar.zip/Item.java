package ch09.mycar;

public class Item {

}
