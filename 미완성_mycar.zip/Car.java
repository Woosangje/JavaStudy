package ch09.mycar;

public class Car {
	
	String carName;//카트바디
	int speed;//
	int maxSpeed;//200
	int acceleration;//가속 )1300 가속력은 현재속도의 +130%라고 판단한다.
	int accelerationTime;//가속시간 예)1000
	//카트바디
	
	

}
