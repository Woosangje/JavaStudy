package ch09.mycar;

import java.util.Scanner;

import ch09.mycar.characters.Charactor;
import ch09.mycar.tires.Tire;
import ch09.mycar.tires.TireList;

public class myCarExam {

	private static Charactor character = null;
	private static Scanner in = new Scanner(System.in);
	private static TireList tireList = new TireList();
	private static Character[] userCharacters = new Character[3];
	
	
	public static void main(String[] args) {
		//
		// ire tire = new Tire();
		Item item = new Item();

		System.out.println("1.플레이   2.인벤토리   3.종료");

		boolean isRun = true;
		while (isRun) {
			int select = in.nextInt();
			switch (select) {
			case 1:
				if (character == null) {
					System.out.println("캐릭터를 선택해주세요");
				} else {

				}
				break;
			case 2:
				boolean isRun2 = true;
				while (isRun2) {

					//Tire tire = tireList.yellowTire;
					System.out.println("------- 현재 장비 -----");
					System.out.println("캐릭터: " + character);
					//System.out.println("타이어: " + tire);
					System.out.println("------- ------ -----\n");
					System.out.println("------- 장비변경 -------");
					System.out.println("1. 캐릭터    2. 타이어  3. 종료");
					int select2 = in.nextInt();
					switch (select2) {
					case 1:
						System.out.println("------- ------ -----");
						System.out.println("현재 캐릭터: " + character);
						System.out.println("------- ------ -----");
						System.out.println("---- 보유 캐릭터 목록 ----");
						System.out.println();
						
						break;
					case 2:
						break;

					}

				}

				break;
			case 3:
				break;
			default:
				break;

			}
		}
	}

}
