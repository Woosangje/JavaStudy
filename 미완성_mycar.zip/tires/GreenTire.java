package ch09.mycar.tires;

public class GreenTire extends Tire{

	public GreenTire() {
		this.name = "그린 프레임";
		this.speed = 0;
		this.maxSpeed = 2;
		this.explanation = "강력한 프레임은 충돌로 부터 차체를 보호합니다. 아님말고";
	}
}
