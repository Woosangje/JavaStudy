package ch09.mycar.tires;

public class BlueTire extends Tire {

	public BlueTire() {
		this.name = "블루 프레임";
		this.speed = 1;
		this.maxSpeed = 1;
		this.explanation = "강력한 프레임은 충돌로 부터 차체를 보호합니다.";
	}
}
