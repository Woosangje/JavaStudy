package ch09.mycar.tires;

public class YellowTire extends Tire {

	public YellowTire() {
		this.name = "옐로우 프레임";
		this.speed = 0;
		this.maxSpeed = 2;
		this.explanation = "강력한 프레임은 충돌로 부터 차체를 보호합니다.";
	}
}
