package ch09.mycar.tires;

public abstract class Tire {
	String name;
	int speed;//
	int maxSpeed;//+2 까지만
	String explanation;
	public Tire() {}
	
	
	
}
