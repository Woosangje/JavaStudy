package ch09.mycar.characters;

public class Charactor {
	String name;
	public Charactor() {
		this.name = null;
	}
	public Charactor(String name) {
		this.name = name;
	}


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	

}
