package ch09.mycar.characters;

public class CharacterList  {
	final String nameDao = "디오";//다오
	final String nameDisney = "디지니";//디지니
	final String nameMorse = "모스";//모스
	
	
	Character createCharacter(String name) {
		
		Character character = new Character(name);
	}
	
	
}
