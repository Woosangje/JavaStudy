package ch14.list;

public class Board {
	String subject ; // 제목
	String contents ; // 내용
	String writer ; // 작성자
	
	public Board(String subject, String contents, String writer) {
		super();
		this.subject = subject;
		this.contents = contents;
		this.writer = writer;
	}
	
	
}
