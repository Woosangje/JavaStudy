package ch08.EzSchool;

import java.util.Scanner;

public class Stats {
	private static Scanner in = new Scanner(System.in);
	
	public Stats() {
		
	}
	
	
	static void addStudent(Student[][] studentArr) {
		// case 학생추가
		boolean isRun = true;
		while (isRun) {
			System.out.println("학생을 추가하시겠습니까? ");
			System.out.println("1. 예 \t2. 아니요 \n");
			int createSelect = in.nextInt();

			switch (createSelect) {
			case 1:
				System.out.println("학년: ");
				int grade = in.nextInt();
				System.out.println("반: ");
				int number = in.nextInt();
				System.out.println("학생이름: ");
				String name = in.next();

				Student newStudent = new Student(grade, number, name);// 학년, 반, 이름

				Outter: for (int i = 0; i < studentArr.length; i++) {

					for (int j = 0; j < studentArr[i].length; j++) {

						if (studentArr[grade - 1][i] == null) {
							studentArr[grade - 1][i] = newStudent;
							System.out.printf("학생추가 완료 \n%d학년, %d반 이름: %s \n", studentArr[grade - 1][i].getGrade(),
									studentArr[grade - 1][i].getNumber(), studentArr[grade - 1][i].getName());
							isRun = false;
							break Outter;// null 비교라 중요
						}
					}
				} // i for end
				System.out.println("");
				break;
			case 2:
				isRun = false;
				break;
			default:
				System.out.println("입력오류");
				break;

			}

		} // while (true) end
	}// void addStudent() end

	static void createScores(Student[][] studentArr) {
		System.out.println("-----------성적이 입력안된 학생 목록 ------------");

		for (int i = 0; i < studentArr.length; i++) {
			for (int j = 0; j < studentArr[i].length; j++)
				if (studentArr[i][j] != null && studentArr[i][j].getScore().getAvgScore() == 0) {
					Reporter.printStudentInfo(studentArr[i][j]);// 프린드 학생배열, 학년
				}

		}
		System.out.println("------------------------------------\n");
		System.out.println("성적을 입력할 학생의 이름을 알려주세요.");
		System.out.println("학생이름: ");
		String name = in.next();
		Student student = findStudent(studentArr, name);
		if (student == null) {
			System.out.println("해당 학생이 존재하지 않습니다.");

		} else {
			// 국영수 입력
			System.out.printf("학생이름확인: %s\n", name);
			System.out.println("국어점수 입력: ");
			int koreanScore = checkInputScore();// 0~100인지확인
			System.out.println("영어점수 입력: ");
			int englishScore = checkInputScore();
			System.out.println("수학점수 입력: ");
			int mathScore = checkInputScore();

			student.Score(koreanScore, englishScore, mathScore);// 국영수 입력
			System.out.printf("국어점수: %d  영어점수: %d  수학점수: %d\n", student.score.getKoreanScore(),
					student.score.getEnglishScore(), student.score.getMathScore());

			//
		}
	}
	private static int checkInputScore() {
		boolean isRun = true;
		while (isRun) {
			int score = in.nextInt();
			if (score >= 0 && score <= 100) {
				isRun = false;
				return score;
			} else {
				System.out.println("ex) 0과 100 사이로 입력해주세요.");
			}
		}
		return 0;
	}
	private static Student findStudent(Student[][] studentArr, String name) {
		// 이름만으로 찾기
		Student student = null; // 빈객체를 생성
		for (int i = 0; i < studentArr.length; i++) {
			for (int j = 0; j < studentArr[i].length; j++) {

				if (studentArr[i][j] != null) { // 빈칸이 아니면
					String dbName = studentArr[i][j].getName();

					// 배열에서 ano값을 가져온다(0~99)
					if (dbName.equals(name)) {
						student = studentArr[i][j];// 얕은복사

					} else {
					}
				} // null 값이 아닌지 if문 종료
			}
		} // 배열 반복용 코드

		return student;

	}

}
