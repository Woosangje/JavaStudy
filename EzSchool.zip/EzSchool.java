package ch08.EzSchool;

import java.util.Scanner;

import ch08.bank.Account;

public class EzSchool {

	private static Student[][] studentArr = new Student[3][100];// 3학년 까지 존재
	private static Scanner in = new Scanner(System.in);
	public static void main(String[] args) {
		// 성적처리 프로그램

		int allStudentsTotalScore;
		int allStudentsAvgScore;

		boolean isRun = true;

		while (isRun) {
			System.out.println("1. 학생추가  2. 성적입력  3. 학년별 정보  4. 성적표출력");
			System.out.println("5. 종료 \t6. 랜덤 학생및점수 생성 ");
			int select = in.nextInt();

			switch (select) {
			case 1: // 학생추가
				Stats.addStudent(studentArr);

				break;
			case 2:// 성적입력
				Stats.createScores(studentArr);
				break;
			case 3:// 학생부

				boolean isRun3 = true;
				while (isRun3) {
					System.out.println("검색할 학년입력");
					int select3 = in.nextInt();
					System.out.println("------------------------------------");

					for (int i = 0; i < studentArr[select3 - 1].length; i++) {
						if (studentArr[select3 - 1][i] != null) {
							Reporter.printStudentInfo(studentArr[select3 - 1][i]);// 프린드 학생배열, 학년
						}

					}
					System.out.println("------------------------------------\n");
					isRun3 = false;

				} // while (isRun3) end

				break;
			case 4:
				// 성적표 출력 3가지, 학년정보, 학급정보, 학생정보

				System.out.println("찾으려는 학생이름: ");
				String grade = in.next();
				break;
			case 5:
				isRun = false;
				break;
			case 6:
				break;
			default:
				System.out.println("입력오류");
				break;

			}
		}

	}

	

	



}
