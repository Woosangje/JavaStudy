package ch08.EzSchool;

public class Student {
	//학년 반 이름
	private int grade;
	private int number;
	private String name;
	
	public Score score;
	public Student(int grade, int number, String name) {

		this.grade = grade;
		this.number = number;
		this.name = name;
		this.score = new Score();
	}
	public Student(Score score) {

		this.score = score;
	}
	
	
	public int getGrade() {
		return grade;
	}
	public int getNumber() {
		return number;
	}
	public String getName() {
		return name;
	}
	
	public void setGrade(int grade) {
		this.grade = grade;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	public void setName(String name) {
		this.name = name;
	}

	//          Score 클래스
	public Score getScore() {
		return score;
	}

	public void setScore(Score score) {
		this.score = score;
	}
	public void Score(int koreanScore, int englishScore, int mathScore) {
		// 
		score.setKoreanScore(koreanScore);
		score.setEnglishScore(englishScore);
		score.setMethScore(mathScore);
		score.setTotalScore(koreanScore, englishScore, mathScore);
		score.setAvgScore(koreanScore, englishScore, mathScore);
	}
	
	
}
