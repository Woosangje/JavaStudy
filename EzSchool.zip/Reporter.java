package ch08.EzSchool;

import java.util.Scanner;

public class Reporter {
	private static Scanner in = new Scanner(System.in);

	public Reporter() {

	}

	static void printStudentInfo(Student studentArr) {
		// 학생정보리스트 출력 전교생뱅열, 학년
		System.out.printf(" %d학년  %d반  이름: %s  국어 %d점  영어 %d점  수학 %d점  평균 %.1f점 \n",
				studentArr.getGrade(), 
				studentArr.getNumber(), 
				studentArr.getName(),
				studentArr.getScore().getKoreanScore(), 
				studentArr.getScore().getEnglishScore(),
				studentArr.getScore().getMathScore(), 
				studentArr.getScore().getAvgScore());

	}
	
	


}
