package ch08.WebBoard;

public class ItemBoard extends Board {
	//변수 상품이름추가할것
	String productName;
	
	
	public ItemBoard() {
		//랜덤을 위한 사용자 클래스
		super("", "", "", "", 0, 0);
		this.productName = "";
	}

	public ItemBoard(String id, String password, String title, String contents, int views, int recommendations,
			String productName) {
		super(id, password, title, contents, views, recommendations);
		this.productName = productName;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}
	
	public void setRandomItemBoardInfo() {
		//랜덤 입력
		this.id = "가나다라";
		this.password ="1234";
		this.title = "좀 짠거같다.";
		this.contents = "ㅇㅇ좀 짠거같다.좀 단거같다.ㅇㅇ";
		this.views = 0;
		this.recommendations = 0;
		this.productName ="";
	}
}
