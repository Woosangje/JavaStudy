package ch08.WebBoard;

public class Member {
	
	//필드
	//게시팜 내용, 
	String id;
	String password;
	
	
	
	public Member() {
		super();
		this.id ="";
		this.password = "";
	}



	public Member(String id, String password) {
		super();
		this.id = id;
		this.password = password;
	}



	public String getId() {
		return id;
	}



	public String getPassword() {
		return password;
	}



	public void setId(String id) {
		this.id = id;
	}



	public void setPassword(String password) {
		this.password = password;
	}



	void printUserInfo() {
		System.out.printf("아이디: %s  패스워드: %s \n", id, password);
	}



	@Override
	public String toString() {
		return "Member [id=" + id + ", password=" + password + "]";
	}
	
}
