package ch08.WebBoard;

public class FreeBoard {
	String nickName;
	String title;
	
	//게시판 닉네임, 제목
	//글쓰기
	//
	
	//기본 생성자(자동)
}
