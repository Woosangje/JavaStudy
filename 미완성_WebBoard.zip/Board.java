package ch08.WebBoard;

public class Board extends Member{

	String title;
	String contents;//내용
	int views;//조회수
	int recommendations;//추천
	
	public Board(String id, String password, String title, String contents, int views, int recommendations) {
		super(id, password);
		this.title = title;
		this.contents = contents;
		this.views = views;
		this.recommendations = recommendations;
	}
	


	
}
