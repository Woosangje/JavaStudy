package ch08.WebBoard;

import java.util.Scanner;

public class WebBoardExam {

	private static Scanner in = new Scanner(System.in);
	private static Member[] memberArr = new Member[100];// 계정생성
	private static Member loggedInMember = null;
	
	//게시판
	private static ItemBoard[] itemBoardArr = new ItemBoard[100];
	
	public static void main(String[] args) {
		//
		boolean isRun = true;
		while (isRun) {
			System.out.println("1. 로그인  2. 회원가입  3. 게시판  4. 종료");
			System.out.println("5. 관리자");
			int select = in.nextInt();
			switch (select) {
			case 1:
				login();
				break;
			case 2:
				createAccount();
				break;
			case 3:
				// 로그인 해야 입장가능
				if (loggedInMember != null) {
					System.out.println("--              게시판              --");
					System.out.println("1. 상품 게시판   2. 자유게시판   3. 뒤로가기");
					int select3 = in.nextInt();
					switch (select3) {
					case 1:
						//상품게시판임의로 추가
						for(int i=0; i < 10; i++) {
							for(int j=0; j< itemBoardArr.length; j++) {
								if(itemBoardArr[j] == null) {
									itemBoardArr[j] =new ItemBoard();
									////////////////////////////////////랜덤 값넣어야함
								}
							}
							
						}
						
						break;
					case 2:
						break;
					case 3:
						break;
					default:
						break;

					}

				} else {
					System.out.println("로그인시 이용가능합니다.");
				}
				break;
			case 4:
				System.out.println("종료");
				isRun = false;
				break;
			case 5:
				break;
			default:
				System.out.println("입력오류");
				break;
			}
		}
	}

	private static void login() {
		// case 로그인
		System.out.println("-----     로그인     -----");
		System.out.println("아이디: ");
		String id = in.next();
		System.out.println("패스워드: ");
		String password = in.next();
		loggedInMember = findMember(id, password);
		if (loggedInMember != null) {
			// 로그인되었을경우
			System.out.println("로그인이 되었습니다.");
			loggedInMember.printUserInfo();

			if (loggedInMember == null) {
				System.out.println("로그인 오류 발생");
			}

		} else {
			System.out.println("아이디나 패스워드가 다릅니다.");
		}
	}

	private static void createAccount() {
		// 회원가입
		System.out.println("-----     계정생성     -----");
		System.out.println("아이디: ");

		String id = findId(in.next());
		System.out.println("패스워드: ");
		String password = in.next();

		Member newMember = new Member(id, password);

		for (int i = 0; i < memberArr.length; i++) {// 아이디생성
			if (memberArr[i] == null) {
				memberArr[i] = newMember;
				System.out.println("--      생성완료      --");
				memberArr[i].printUserInfo();
				break;
			}
		}

	}

	private static String findId(String id) {

		for (int i = 0; i < memberArr.length; i++) {
			if (memberArr[i] != null) { // 빈칸이 아니면
				String dbId = memberArr[i].getId();

				if (dbId.equals(id)) {
					// 같은 id가 이미 존재하는지
					System.out.println("이미 존재하는 아이디 입니다.");
					return null;
				}

			}
		} // 배열 반복용 코드
		return id;

	}

	private static Member findMember(String id, String password) {
		// memberArr 에서 반환
		Member member = null;
		for (int i = 0; i < memberArr.length; i++) {
			if (memberArr[i] != null) {
				String dbId = memberArr[i].getId();
				String dbPw = memberArr[i].getPassword();
				if (dbId.equals(id) && dbPw.equals(password)) {
					member = memberArr[i];
					break;
				} else {

				}
			}

		}

		return member;
	}

}
